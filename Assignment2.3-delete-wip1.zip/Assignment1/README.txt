Assignment
----------

1. Add two more companies to the start page
2. Add 3 products for each company
3. Show the logo for each company and each product ( similar to the UITableView project)
4. Add a 3rd level to the app so that a web page related to the product is shown when a product is selected. Hint: Use the class UIWebView 
5. Enable delete functionality on the products page so that products can be deleted.
