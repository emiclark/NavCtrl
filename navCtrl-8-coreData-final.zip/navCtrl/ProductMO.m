//
//  ProductMO.m
//  NavCtrl
//
//  Created by Aditya Narayan on 4/12/16.
//  Copyright © 2016 Aditya Narayan. All rights reserved.
//

#import "ProductMO.h"
#import "CompanyMO.h"

@implementation ProductMO

// Insert code here to add functionality to your managed object subclass


@end
