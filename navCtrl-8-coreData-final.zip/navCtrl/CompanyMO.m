//
//  CompanyMO.m
//  NavCtrl
//
//  Created by Aditya Narayan on 4/12/16.
//  Copyright © 2016 Aditya Narayan. All rights reserved.
//

#import "CompanyMO.h"
#import "ProductMO.h"

@implementation CompanyMO

// Insert code here to add functionality to your managed object subclass

@end
