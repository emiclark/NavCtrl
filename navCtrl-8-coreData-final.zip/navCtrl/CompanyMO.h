//
//  CompanyMO.h
//  NavCtrl
//
//  Created by Aditya Narayan on 4/12/16.
//  Copyright © 2016 Aditya Narayan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class ProductMO;

NS_ASSUME_NONNULL_BEGIN

@interface CompanyMO : NSManagedObject

// Insert code here to declare functionality of your managed object subclass

@end

NS_ASSUME_NONNULL_END

#import "CompanyMO+CoreDataProperties.h"
